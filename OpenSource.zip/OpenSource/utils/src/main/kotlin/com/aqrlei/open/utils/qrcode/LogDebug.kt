package com.aqrlei.open.utils.qrcode

import android.util.Log

/**
 * @author aqrlei on 2018/9/18
 */
fun logDebug(msg: String) {
    Log.d("QRCode", msg)
}